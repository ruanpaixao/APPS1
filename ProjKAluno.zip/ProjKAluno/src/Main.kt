fun calcularMedia(nota1: Double, nota2: Double): Double {
    return (nota1 + nota2) / 2
}

fun main() {
    print("\nDigite o nome do aluno: ")

    val nomeAluno = readln()

    print("Digite a nota 1 do aluno: ")
    val nota1 = readln() !!.toDouble()

    print("Digite a nota 2 do aluno: ")
    val nota2 = readln() !!.toDouble()

    val media = calcularMedia(nota1, nota2)

    println("\nDados do aluno: \n" +
            "Nome: $nomeAluno \n" +
            "Nota 1: $nota1 \n" +
            "Nota 2: $nota2 \n" +
            "Média: $media \n")



    val situacao = if (media >= 6) {
        "Aprovado"
    } else {
        "Reprovado"
    }

    println("Situação: $situacao")






}